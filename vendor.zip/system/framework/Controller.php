<?php

  namespace System;

  use System\View;

  class Controller
  {


    public function __construct ()
    {


    }

  }
?>
