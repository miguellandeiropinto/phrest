<?php

  namespace MyApp\Controllers;

  use System\Controller;

  class GenresController extends Controller {

    public function GET ( Request $request )
    {

    }

    public function POST ( Request $request )
    {

    }

    public function PUT ( Request $request )
    {

    }

    public function DELETE ( Request $request )
    {

    }


  }

?>
