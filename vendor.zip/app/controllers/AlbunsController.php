<?php

  namespace MyApp\Controllers;

  use System\Controller;

  class AlbunsController extends Controller {

    public function GET ()
    {
      
    }

    public function POST ()
    {

    }

    public function PUT ()
    {

    }

    public function DELETE ()
    {

    }


  }

?>
