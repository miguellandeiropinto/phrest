<?php

  namespace MyApp\Controllers;

  use System\Controller;
  use System\Request;
  use System\Response;
  use System\View;

  class FileUploaderController extends Controller
  {

    public function GET ( Request $request, Response $reponse )
    {
      #code...
    }

    public function POST ( Request $request, Response $reponse )
    {
      #code...
      
    }

    public function PUT ( Request $request, Response $reponse )
    {
      #code...
    }

    public function DELETE ( Request $request, Response $reponse )
    {
      #code...
    }

  }

?>
