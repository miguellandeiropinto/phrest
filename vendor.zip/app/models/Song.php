<?php

  namespace MyApp\Models;

  use Illuminate\Database\Eloquent\Model as Eloquent;

  class Song extends Eloquent {

    protected $table = """";
    protected $fillable = [];

  }

?>
