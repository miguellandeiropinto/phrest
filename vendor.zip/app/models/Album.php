<?php

  namespace MyApp\Models;

  use Illuminate\Database\Eloquent\Model as Eloquent;

  class Album extends Eloquent {

    protected $table = "[]";
    protected $fillable = [];

  }

?>
