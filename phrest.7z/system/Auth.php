<?php

  namespace System;

  use OAuth2\GrantType\IGrantType;
  use OAuth2\GrantType\AuthorizationCode;
  use OAuth2\Client;

  class Auth {

    public function handle () {

      $client = new Client();

      if ( !API_KEY ) {

      } else {



      }

    }

  }

?>
